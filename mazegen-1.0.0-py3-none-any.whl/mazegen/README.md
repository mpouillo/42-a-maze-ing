## MazeGenerator Documentation

The MazeGenerator class is a standalone module that can be imported and used in any project.<br>
The package is available as `mazegen-1.0.0-py3-none-any.whl` at the root of the project files and can also be recreated by doing `make build`.

It's the main interface for creating, solving, and managing mazes. It can generate both square and hexagonal mazes, find solutions, and save the results.


### 1. Instantiation and Basic Usage

To use the `MazeGenerator`, you first need to set up the configuration using environment variables. Then, you can instantiate the class and call its methods to generate and access maze data.

#### Configuration

The generator is configured via environment variables. These are loaded from a `config.txt` file at the root of the project when running the application, but you can also set them manually in your script.


#### Example

Here is a basic example of how to generate a 10x10 square maze and save it.

```python
import os
import sys
from mazegen import MazeGenerator

# --- 1. Set up configuration ---
# The generator reads these from the environment.
os.environ['WIDTH'] = '20'
os.environ['HEIGHT'] = '20'
os.environ['ENTRY'] = '0,0'
os.environ['EXIT'] = '19,19'
os.environ['PERFECT'] = 'True'
os.environ['OUTPUT_FILE'] = 'maze.txt'

# --- 2. Instantiate the generator ---
# This will automatically load the configuration from the environment.
try:
    maze_generator = MazeGenerator()
except ValueError as e:
    print(f"Error initializing generator: {e}")
    sys.exit(1)

# --- 3. Generate the maze ---
# This populates the maze data and saves it to the output file.
maze_generator.generate_new_maze()

print(f"Maze generated and saved to {maze_generator.output_file}")
```

### 2. Accessing Maze Data

After calling `generate_new_maze()`, you can access the generated maze structure and its solutions directly from the `MazeGenerator` instance.

#### Accessing the Maze Structure

The maze is stored as a NumPy array where each cell is an integer representing its walls.

-   **`maze_generator.maze`**: A `numpy.ndarray` representing the final maze structure.
    -   For square mazes, walls are represented by a 4-bit integer (`NESW`):
        - WEST = 1 (2⁰)
        - SOUTH = 2 (2¹)
        - EAST = 4 (2²)
        - NORTH = 8 (2³)

    -   For hexagonal mazes, walls are represented by a 6-bit integer.
        - TOP_RIGHT = 1 (2⁰)
        - RIGHT = 2 (2¹)
        - BOTTOM_RIGHT = 4 (2²)
        - BOTTOM_LEFT = 8 (2³)
        - LEFT = 16 (2⁴)
        - TOP_LEFT = 32 (2⁵)

```python
# Access the generated maze grid
maze_grid = maze_generator.maze
print("Generated Maze Grid (first 5 rows):")
print(maze_grid[:5])
```

#### Accessing Solutions

The generator finds one or more valid paths from the entry to the exit.

-   **`maze_generator.valid_paths`**: A list of all found paths. Each path is a list of `(row, col)` coordinate tuples. The list is sorted by path length, with the shortest path first.

You can also save a specific solution path directly to the output file.

```python
# Get the shortest solution path
if maze_generator.valid_paths:
    shortest_path_coords = maze_generator.valid_paths[0]
    
    print(f"\nFound {len(maze_generator.valid_paths)} solution(s).")
    print(f"Shortest path has {len(shortest_path_coords)} steps.")

    print(f"Shortest solution saved to {maze_generator.output_file}.")
else:
    print("No solution was found.")
```

